package pkg_3;

public class Pessoa extends SerHumano {

    public Pessoa(String nome, int idade, String tipo) {
        super(nome, idade, tipo);
    }
}